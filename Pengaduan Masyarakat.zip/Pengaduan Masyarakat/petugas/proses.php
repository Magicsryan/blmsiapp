<?php
include '../koneksi.php';
//memanggil database
$sql=(" update pengaduan set status='proses' where id_pengaduan='$_GET[id]'");
$cek=($sql);
if($cek='status')
$data=mysqli_query($koneksi,$sql);
$userData=($data);
{ header('location:petugas.php?url=verifikasi_pengaduan'); }
?>
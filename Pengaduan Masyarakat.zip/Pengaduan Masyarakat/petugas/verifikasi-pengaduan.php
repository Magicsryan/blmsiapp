<?php
$id = $_GET['id'];
if (empty($id)) {
    header("Location:masyarakat.php");
    exit; // it's a good practice to exit after a header redirection
}include 'koneksi.php';
$query = mysqli_query($koneksi, "SELECT * FROM pengaduan WHERE id_pengaduan='$id'");
$data = mysqli_fetch_array($query);
?>
<div class="card shadow">
    <div class="card-header">
        <a href="?url=lihat-pengaduan" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
        <form method="post" action="proses-pengaduan.php" enctype="multipart/form-data">
            <div class="form-group">
                <label style="font-size: 14px;">Tgl Pengaduan</label>
                <input type="text" name="tgl_pengaduan" class="form-control" readonly value="<?= $data['Tgl_pengaduan']; ?>">
            </div>
            <div class="form-group">
                <label style="font-size: 14px;">Isi Laporan</label>
                <textarea name="isi_laporan" class="form-control" required><?= $data['Tgl_pengaduan']; ?>"></textarea>
            </div>
            <div class="form-group">
                <label style="font-size: 14px;">Foto</label>
                <img class="img-thumbnail" src="foto/<?= $data['foto'] ?>" width="300">
            </div>
        </form>
    </div>
</div>
    <!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables pengaduan</h6>
    </div>
    <div class="card-body" style="font-size: 14px">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                    <th>ID</th>
<th>Tgl Pengaduan</th>
<th>NIK</th>
<th>Isi Laporan</th>
<th>Fato</th>
<th>Status</th>
<th>Action</th>
</tr>
<?php
$sql="SELECT * FROM pengaduan WHERE status 'proses'";
include '../koneksi.php';
$query = mysqli_query(Skoneksi, $sql);
while ($data = mysqli_fetch_array($query)) ?>
<td><?=$data['id pengaduan']?></td>
<td><?=$data['tal pengaduan']?></td>
<td><?=$data['nik']?></td>
<td><?=$data['isi laporan']?></td>
<td><?=$data['foto']?></td>
<td><?=$data['status']?></td>
<td>
<a href="?url=detail-pengaduan&id=<?$data['id_pengaduan']?>" class="btn btn-info btn-icon-split">
 <span class="icon text-white 5">
<i class="fa fa-info"></i>
</span>
<span class="text">Detail</span>
</a>
<a href="?url=tanggapan&id=<?=$data['id_pengaduan']?>" class="btn btn-danger btn-icon-split">
<span class="icon text-white 5">
<i class="fa fa-check"></i>
</span>
<span class="text">Tanggapan</span>
</a>
